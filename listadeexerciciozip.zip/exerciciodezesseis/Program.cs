﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exerciciodezesseis
{
    class Program
    {
        static void Main(string[] args)
        {
            //exercicio 15
            int i = 100;
            while (i <= 200)
            {
                Console.WriteLine(i++);
            }
            Console.ReadLine();
        }
    }
}
